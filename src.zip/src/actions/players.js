export const setPlayers = players => ({
    type: 'SET_PLAYERS',
    payload: players
});
