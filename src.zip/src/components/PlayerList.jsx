import React from 'react';
import { Card, Image, Button } from 'semantic-ui-react';
import { CircularProgressbar } from 'react-circular-progressbar';
import '../progressbar.css';

const PlayerList = player => {
    const percentage = 66;
    const { name, avatar, position, injury, number, addToList, addedCount, openForm, predictForm } = player;

    return (
        <Card>
            <div className="card-image">
                <Image src={avatar} />
                <div className="container-progressbar">
                    <CircularProgressbar value={percentage} text={`${percentage}%`} />
                </div>
            </div>
            <Card.Content>
                <Card.Header>{name}</Card.Header>
                <div className="number">
                    <Card.Header>number:&nbsp;{number}</Card.Header>
                </div>
                <Card.Meta>
                    <span className="date">position:&nbsp;{position}</span>
                </Card.Meta>
                <Card.Content extra>
                    <a>
                        Травмы:&nbsp;
                    {injury}
                    </a>
                </Card.Content>
                <div>
                    <Button className="open_form" onClick={openForm}>
                        Текущая форма
                        </Button>

                    <Button className="predict_form" onClick={predictForm}>
                        Прогнозная форма
                        </Button>

                    <Button className="select_form" onClick={addToList.bind(this, player)}>
                        Добавить в текущий выбор {addedCount > 0 && `(${addedCount})`}
                    </Button>
                </div>


            </Card.Content>



        </Card >
    );
};

export default PlayerList;
